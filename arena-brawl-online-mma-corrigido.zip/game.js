const $=id=>document.getElementById(id),GY=.02,V3=THREE.Vector3,TAU=Math.PI*2;
const G={st:'menu',mode:'cpu',cam:3,me:0,round:1,time:60,shake:0,freeze:0,slowT:0,coins:0};
const MOBILE=matchMedia('(pointer:coarse)').matches||innerWidth<800;const R=new THREE.WebGLRenderer({antialias:!MOBILE,powerPreference:'high-performance'});R.setPixelRatio(Math.min(devicePixelRatio,MOBILE?1:1.5));R.shadowMap.enabled=!MOBILE;R.shadowMap.type=THREE.PCFShadowMap;$('app').prepend(R.domElement);
const S=new THREE.Scene();S.background=new THREE.Color(0x06060d);S.fog=new THREE.Fog(0x06060d,24,70);
const cam=new THREE.PerspectiveCamera(45,1,.05,120);S.add(cam);
let AW=800,AH=400,ROT=false;
function fit(){const W=innerWidth,H=innerHeight;ROT=H>W;AW=ROT?H:W;AH=ROT?W:H;const a=$('app');a.style.width=AW+'px';a.style.height=AH+'px';a.style.transform=ROT?'translate('+W+'px,0) rotate(90deg)':'none';a.style.setProperty('--u',AH/100+'px');a.classList.toggle('rot',ROT);R.setSize(AW,AH,false);R.setPixelRatio(Math.min(devicePixelRatio,MOBILE?1:1.5));cam.aspect=AW/AH}
addEventListener('resize',fit);addEventListener('orientationchange',()=>setTimeout(fit,250));fit();
const M=(c,r=.55,m=0)=>new THREE.MeshStandardMaterial({color:c,roughness:r,metalness:m});
const SG=new THREE.SphereGeometry(1,20,14),cap=(r,l)=>new THREE.CapsuleGeometry(r,l,5,10);
function mesh(g,m,x,y,z,p,sc){const o=new THREE.Mesh(g,m);o.position.set(x,y,z);if(sc)o.scale.set(sc[0],sc[1],sc[2]);o.castShadow=o.receiveShadow=true;(p||S).add(o);return o}
const bx=(w,h,d,m,x,y,z,p)=>mesh(new THREE.BoxGeometry(w,h,d),m,x,y,z,p);
function ctex(w,h,fn){const c=document.createElement('canvas');c.width=w;c.height=h;fn(c.getContext('2d'),w,h);const t=new THREE.CanvasTexture(c);t.anisotropy=4;return t}
/* luzes */
S.add(new THREE.HemisphereLight(0x99aaff,0x221122,.8));
const key=new THREE.SpotLight(0xffffff,MOBILE?.8:1.3,70,.9,.5);key.position.set(0,18,5);key.castShadow=!MOBILE;key.shadow.mapSize.set(MOBILE?256:768,MOBILE?256:768);S.add(key,key.target);
const beams=[0xff2a4d,0x2a6bff].map((c,i)=>{const l=new THREE.SpotLight(c,2.4,60,.35,.5);l.position.set(i?9:-9,13,-4);S.add(l,l.target);const pv=new THREE.Group();pv.position.copy(l.position);S.add(pv);
const g=new THREE.CylinderGeometry(.05,2.6,13,20,1,true);g.translate(0,-6.5,0);pv.add(new THREE.Mesh(g,new THREE.MeshBasicMaterial({color:c,transparent:true,opacity:.09,blending:THREE.AdditiveBlending,depthWrite:false,side:THREE.DoubleSide})));return{l,pv}});
/* arena */
bx(90,.2,90,M(0x0d0d16,.9),0,-1.2,0);
const cv=ctex(1024,600,(g,w,h)=>{g.fillStyle='#d8d0bd';g.fillRect(0,0,w,h);g.strokeStyle='#c1121f';g.lineWidth=26;g.strokeRect(13,13,w-26,h-26);g.textAlign='center';g.textBaseline='middle';g.fillStyle='#c1121f';g.font='bold 120px Impact,Arial Black,sans-serif';g.fillText('ARENA BRAWL',w/2,h/2-30);g.fillStyle='#1b3fbf';g.font='bold 70px Impact,sans-serif';g.fillText('3D CHAMPIONSHIP',w/2,h/2+75)});
bx(19,.9,11,M(0x1a1a28),0,-.45,0);bx(19.2,.5,11.2,M(0xaa1122),0,-.55,0);
const rg=new THREE.Mesh(new THREE.PlaneGeometry(17,10),new THREE.MeshStandardMaterial({map:cv,roughness:.8}));rg.rotation.x=-Math.PI/2;rg.position.y=.01;rg.receiveShadow=true;S.add(rg);
const front=new THREE.Group(),RC=[0xe0182d,0xffffff,0x1c4fe0];S.add(front);
[[-8.2,-4.7],[8.2,-4.7],[-8.2,4.7],[8.2,4.7]].forEach(([x,z])=>{mesh(new THREE.CylinderGeometry(.15,.15,3,12),M(0x9aa0aa,.4,.6),x,1.5,z);[.8,1.4,2].forEach((y,j)=>mesh(new THREE.CylinderGeometry(.24,.24,.35,14),M(RC[j]),x,y,z))});
[.8,1.4,2].forEach((y,j)=>{const m=M(RC[j],.4);let o=mesh(new THREE.CylinderGeometry(.06,.06,16.4,8),m,0,y,-4.7);o.rotation.z=Math.PI/2;o=mesh(new THREE.CylinderGeometry(.06,.06,16.4,8),m,0,y,4.7,front);o.rotation.z=Math.PI/2;
[-8.2,8.2].forEach(x=>{o=mesh(new THREE.CylinderGeometry(.06,.06,9.4,8),m,x,y,0);o.rotation.x=Math.PI/2})});
const dark=M(0x14141f,.9),slots=[];
for(let t=0;t<5;t++){const rxo=17+t*2.4,rzo=14+t*2.2,h=.9+t*1.1,sh=new THREE.Shape();sh.absellipse(0,0,rxo,rzo,0,TAU,false,0);const ho=new THREE.Path();ho.absellipse(0,0,rxo-2.4,rzo-2.2,0,TAU,true,0);sh.holes.push(ho);
const g=new THREE.ExtrudeGeometry(sh,{depth:h+1.1,bevelEnabled:false,curveSegments:40});g.rotateX(-Math.PI/2);mesh(g,dark,0,-1.1,0);
const n=(MOBILE?10:26)+t*(MOBILE?3:8);for(let k=0;k<n;k++){const a=k/n*TAU;slots.push([Math.cos(a)*(15.8+t*2.4),h,Math.sin(a)*(12.9+t*2.2),Math.random()*9])}}
const NC=slots.length,cb=new THREE.InstancedMesh(cap(.26,.5),M(0xffffff,.8),NC),ch=new THREE.InstancedMesh(SG,M(0xffffff,.8),NC),dm=new THREE.Object3D();
slots.forEach((s,i)=>{cb.setColorAt(i,new THREE.Color().setHSL(Math.random(),.55,.45));ch.setColorAt(i,new THREE.Color().setHSL(.07,.5,.3+Math.random()*.4))});S.add(cb,ch);
function crowdUpd(T,ex){slots.forEach((s,i)=>{const b=Math.abs(Math.sin(T*3+s[3]))*(ex?.55:.12);dm.position.set(s[0],s[1]+.62+b,s[2]);dm.scale.set(1,1,1);dm.updateMatrix();cb.setMatrixAt(i,dm.matrix);dm.position.y=s[1]+1.4+b;dm.scale.setScalar(.22);dm.updateMatrix();ch.setMatrixAt(i,dm.matrix)});cb.instanceMatrix.needsUpdate=ch.instanceMatrix.needsUpdate=true}
const jt=ctex(512,256,(g,w,h)=>{const gr=g.createLinearGradient(0,0,w,0);gr.addColorStop(0,'#c1121f');gr.addColorStop(1,'#1b3fbf');g.fillStyle=gr;g.fillRect(0,0,w,h);g.fillStyle='#fff';g.font='bold 84px Impact,sans-serif';g.textAlign='center';g.fillText('ARENA',w/2,110);g.fillText('BRAWL 3D',w/2,205)});
const jb=bx(8,3.2,8,new THREE.MeshBasicMaterial({map:jt}),0,10.5,0);jb.castShadow=false;
/* lutador modelado: cabeca, olhos, cabelo, tronco, ombros, cotovelos, joelhos, luvas, botas */
function mk(d){const g=new THREE.Group();S.add(g);const sk=M(d.sk,.65),cl=M(d.c,.45),gl=M(d.c,.25,.15),hr=M(d.hr,.8),dk=M(0x15151c,.7),wh=M(0xffffff,.4);
const up=new THREE.Group();up.position.y=1.45;g.add(up);const body=new THREE.Group();up.add(body);
mesh(SG,sk,0,.55,0,body,[.3,.5,.5]);mesh(cap(.25,.2),sk,0,0,0,body,[1,1,1.4]);
mesh(new THREE.CylinderGeometry(.36,.4,.58,18),cl,0,-.3,0,body,[1,1,1.25]);mesh(new THREE.CylinderGeometry(.37,.37,.1,18),M(0xffd23d,.3,.8),0,-.02,0,body,[1,1,1.25]);
mesh(new THREE.CylinderGeometry(.11,.13,.2,10),sk,0,.95,0,body);
const h=new THREE.Group();h.position.y=1.3;body.add(h);mesh(SG,sk,0,0,0,h,[.26,.3,.26]);mesh(SG,hr,-.07,.12,0,h,[.27,.22,.28]);
const hb=mesh(new THREE.TorusGeometry(.27,.035,8,24),cl,0,.07,0,h);hb.rotation.x=Math.PI/2;
[-1,1].forEach(z=>{mesh(SG,wh,.22,.05,z*.11,h,[.055,.05,.05]);mesh(SG,dk,.265,.05,z*.11,h,[.03,.03,.03]);const b=mesh(new THREE.BoxGeometry(.04,.025,.1),dk,.25,.14,z*.11,h);b.rotation.x=z*.35;mesh(SG,sk,0,0,z*.26,h,[.05,.07,.05])});
mesh(SG,sk,.27,-.03,0,h,[.04,.05,.04]);bx(.02,.02,.12,dk,.255,-.14,0,h);
const arm=z=>{const sh=new THREE.Group();sh.position.set(0,.85,z);up.add(sh);mesh(SG,sk,0,0,0,sh,[.17,.17,.17]);mesh(cap(.115,.26),sk,0,-.25,0,sh);const el=new THREE.Group();el.position.y=-.5;sh.add(el);mesh(SG,sk,0,0,0,el,[.11,.11,.11]);mesh(cap(.1,.24),sk,0,-.22,0,el);mesh(SG,gl,0,-.52,0,el,[.2,.2,.22]);return{sh,el}};
const leg=z=>{const hp=new THREE.Group();hp.position.set(0,1.2,z);g.add(hp);mesh(cap(.16,.26),sk,0,-.3,0,hp);const kn=new THREE.Group();kn.position.y=-.58;hp.add(kn);mesh(SG,sk,0,0,0,kn,[.14,.14,.14]);mesh(cap(.125,.24),sk,0,-.26,0,kn);mesh(SG,gl,.09,-.55,0,kn,[.27,.12,.15]);return{hp,kn}};
return{g,up,body,head:h,cl,gl,sk,hr,aF:arm(.5),aB:arm(-.5),lF:leg(.2),lB:leg(-.2)}}
const A={punch:{d:.35,h:.12,r:1.8,dm:7,kb:3.5},kick:{d:.55,h:.25,r:2.2,dm:12,kb:5.5},sp:{d:.8,h:.3,r:2.8,dm:28,kb:10}};
const P=[{c:0xe0182d,sk:0xe0ac69,hr:0x2b1b12},{c:0x1c5fe0,sk:0x8d5524,hr:0xe8d27a}].map((d,i)=>({i,f:mk(d),nm:i?'AZUL':'VERMELHO',wins:0,cpu:false,remote:false,sq:0,lh:0,x:i?3:-3,y:0,vy:0,vx:0,hp:100,mt:0,st:'idle',t:0,face:i?-1:1,peer:null,in:{}}));
/* entrada: teclado + joystick virtual + botoes de acao */
const KM=[{KeyA:'l',KeyD:'r',KeyW:'u',KeyS:'v',Space:'j',KeyF:'a',KeyG:'k',KeyH:'b',KeyR:'s',KeyE:'d'},{ArrowLeft:'l',ArrowRight:'r',KeyI:'u',KeyM:'v',ArrowUp:'j',KeyK:'a',KeyL:'k',Semicolon:'b',KeyO:'s',Period:'d'}],dn=[{},{}];
['keydown','keyup'].forEach(t=>addEventListener(t,e=>{if(document.activeElement.tagName=='INPUT')return;if(t=='keydown'&&e.code=='KeyC'&&G.st!='menu')camNext();KM.forEach((m,i)=>{if(m[e.code]){dn[G.mode=='net'?0:i][m[e.code]]=t=='keydown'?1:0;e.preventDefault()}})}));
if(matchMedia('(pointer:coarse)').matches||'ontouchstart' in window)$('app').classList.add('touch');
function goLand(){try{const e=document.documentElement,lk=()=>{try{screen.orientation.lock('landscape').catch(()=>{})}catch(_){}};lk();if(e.requestFullscreen&&!document.fullscreenElement)e.requestFullscreen().then(lk).catch(()=>{})}catch(_){}}
function joy(el,i){const kn=el.firstElementChild;let id=null,cx=0,cy=0;
const rel=()=>{const d=dn[i];d.l=d.r=d.u=d.v=0;kn.style.transform='translate(-50%,-50%)'};
function mv(e){let x=e.clientX-cx,y=e.clientY-cy;if(ROT){const t=x;x=y;y=-t}const m=el.offsetWidth*.36,l=Math.hypot(x,y)||1,k=Math.min(1,m/l);x*=k;y*=k;kn.style.transform='translate(calc(-50% + '+x+'px),calc(-50% + '+y+'px))';const d=dn[i];d.l=x<-m*.35?1:0;d.r=x>m*.35?1:0;d.u=y<-m*.35?1:0;d.v=y>m*.35?1:0}
el.onpointerdown=e=>{id=e.pointerId;try{el.setPointerCapture(id)}catch(_){}const r=el.getBoundingClientRect();cx=r.left+r.width/2;cy=r.top+r.height/2;mv(e);e.preventDefault()};
el.onpointermove=e=>{if(e.pointerId==id)mv(e)};['pointerup','pointercancel'].forEach(t=>el['on'+t]=e=>{if(e.pointerId==id){id=null;rel()}})}
document.querySelectorAll('.joy').forEach(el=>joy(el,+el.dataset.p));
document.querySelectorAll('.acts').forEach(box=>{const i=+box.dataset.p;[['a','👊','SOCO'],['k','🦵','CHUTE'],['b','🛡️','DEFESA'],['j','⤒','PULO'],['d','💨','ESQUIVA'],['s','⚡','SUPER']].forEach(([k,ic,lb])=>{const b=document.createElement('button');b.className='ab '+k;b.innerHTML='<b>'+ic+'</b><small>'+lb+'</small>';
b.onpointerdown=e=>{dn[i][k]=1;b.classList.add('on');try{navigator.vibrate(10)}catch(_){}e.preventDefault()};['pointerup','pointerleave','pointercancel'].forEach(t=>b['on'+t]=()=>{dn[i][k]=0;b.classList.remove('on')});b.oncontextmenu=e=>e.preventDefault();box.appendChild(b)})});
/* audio e efeitos */
let AC;function snd(f,d,ty='square',v=.12){try{AC=AC||new AudioContext();const o=AC.createOscillator(),g=AC.createGain(),t=AC.currentTime;o.type=ty;o.frequency.setValueAtTime(f,t);o.frequency.exponentialRampToValueAtTime(40,t+d);g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.001,t+d);o.connect(g);g.connect(AC.destination);o.start();o.stop(t+d)}catch(e){}}
const sparks=[];
function spark(x,y,c){for(let i=0;i<10;i++){const m=new THREE.Mesh(new THREE.BoxGeometry(.14,.14,.14),new THREE.MeshBasicMaterial({color:c}));m.position.set(x,y,.3);S.add(m);sparks.push({m,l:.5,v:new V3((Math.random()-.5)*7,Math.random()*5,(Math.random()-.5)*4)})}}
function confetti(c){for(let i=0;i<80;i++){const m=new THREE.Mesh(new THREE.BoxGeometry(.18,.04,.12),new THREE.MeshBasicMaterial({color:i%3?c:0xffd23d}));m.position.set((Math.random()-.5)*10,7+Math.random()*2,(Math.random()-.5)*6);S.add(m);sparks.push({m,l:3,g:1.5,v:new V3((Math.random()-.5)*2,-1-Math.random()*2,(Math.random()-.5)*2)})}}
function msg(t,s){const m=$('msg');m.textContent=t;m.style.display=t?'block':'none';if(s)setTimeout(()=>{if(m.textContent==t)m.style.display='none'},s*1000)}
let fxT;function fx(t){const e=$('fx');e.textContent=t;e.style.opacity=1;clearTimeout(fxT);fxT=setTimeout(()=>e.style.opacity=0,450)}
/* regras */
function reset(p){Object.assign(p,{x:p.i?3:-3,z:0,y:0,vy:0,vx:0,vz:0,hp:100,mt:0,st:'idle',t:0,face:p.i?-1:1,dodge:0})}
function pips(){[0,1].forEach(i=>$('w'+(i+1)).textContent='●'.repeat(P[i].wins)+'○'.repeat(3-P[i].wins))}
function startRound(){P.forEach((p,i)=>{reset(p);p.x=i?9:-9;p.z=i?1.5:-1.5;p.face=i?-1:1;p.st='walk'});G.st='intro';G.introT=0;G.time=60;pips();$('intro-name1').textContent=P[0].nm;$('intro-name2').textContent=P[1].nm;$('intro-card').classList.remove('show');void $('intro-card').offsetWidth;$('intro-card').classList.add('show');msg('');snd(900,.5,'sine',.2)}
function endRound(w){if(G.st!='fight')return;G.st='end';if(w)w.wins++;pips();G.slowT=1.1;msg(w?'K.O.!':'EMPATE');snd(70,.8,'sawtooth',.25);
setTimeout(()=>{if(G.round>=3){const winner=P[0].wins===P[1].wins?null:(P[0].wins>P[1].wins?P[0]:P[1]);if(winner){const localWinner=G.mode=='net'?winner.i===G.me:winner.i===0;if(localWinner){G.coins+=50;G.totalWins=(G.totalWins||0)+1;saveCoins();saveProfileStats()}msg(winner.nm+' VENCEU! 🏆'+(localWinner?'\n+50 MOEDAS':'')+'\n67!');winner.st='victory';winner.t=0;confetti(winner.i?0x3da5ff:0xff4d4d)}else msg('EMPATE!');setTimeout(()=>{if(G.mode=='net'){if(RM&&G.st=='end'){N.played=true;goLobby()}}else toMenu()},4200)}else{G.round++;if(G.st=='end')startRound()}},2100)}
function begin(p,n){p.st=n;p.t=0;p.hit=false;p.sq++;if(n=='sp')p.mt=0;snd(n=='sp'?200:n=='kick'?330:420,.15,'sawtooth',.06)}
function hurt(o,p,a,n){if(o.st=='ko')return;if(o.st=='dodge'&&o.dodge>0){fx('ESQUIVA!');return}const bl=o.st=='block',d=bl?a.dm*(n=='sp'?.4:.12):a.dm;o.hp=Math.max(0,o.hp-d);o.vx=p.face*a.kb*(bl?.3:1);p.mt=Math.min(100,p.mt+a.dm*1.3);
if(bl){snd(120,.1,'square',.1);spark(o.x,2,0x88aaff)}else{o.mt=Math.min(100,o.mt+a.dm*.6);o.st='hit';o.t=0;G.shake=n=='sp'?.7:.3;G.freeze=n=='sp'?.12:.05;snd(n=='sp'?90:160,.25,'sawtooth',.2);spark(o.x,2,n=='sp'?0xffd23d:0xffffff);fx(n=='sp'?'SUPER!!':['POW!','BAM!','WHAM!'][Math.random()*3|0])}
if(o.hp<=0){o.st='ko';o.t=0;G.shake=.9;endRound(p)}}
let dt=.016;
function ai(p,o){p.at=(p.at||0)-dt;const d=Math.hypot(o.x-p.x,(o.z||0)-(p.z||0)),k={};if(p.at<=0){p.at=.2+Math.random()*.3;p.pl=Math.random()}const q=p.pl,to=o.x>p.x?'r':'l',aw=to=='r'?'l':'r';
if(d>1.9)k[to]=1;else if(d<1.2&&q<.3)k[aw]=1;if(Math.abs((o.z||0)-(p.z||0))>.35)k[(o.z||0)<(p.z||0)?'u':'v']=1;
if(d<2.2){if(q<.3)k.a=1;else if(q<.45)k.k=1;else if(q<.7&&/punch|kick|sp/.test(o.st))k.b=1;else if(q>.97)k.j=1}
if(p.mt>=100&&d<2.6)k.s=1;p.in=k}
function upd(p,o){p.t+=dt;if(p.remote)return;
if(p.st!='ko'){p.face=o.x>p.x?1:-1;if(p.dodge>0)p.dodge=Math.max(0,p.dodge-dt);const k=G.st=='fight'?(p.cpu?(ai(p,o),p.in):dn[G.mode=='local'?p.i:0]):{};
if(G.st=='intro'){const target=p.i?2.45:-2.45;const approach=Math.min(1,dt*2.7);if(G.introT<2.35){p.x+=(target-p.x)*approach;p.z+=(0-p.z)*Math.min(1,dt*2.2);p.st='walk'}else{p.x+=(target-p.x)*Math.min(1,dt*5);p.z+=(0-p.z)*Math.min(1,dt*5);p.st='victory'}p.face=p.i?-1:1}
if(p.st=='hit'&&p.t>.3)p.st='idle';if(p.st=='dodge'&&p.t>.32)p.st='idle';
if(p.st=='dodge'){if(p.t>.32)p.st='idle'}else if(['idle','walk','block'].includes(p.st)&&G.st=='fight'){let dx=(k.r?1:0)-(k.l?1:0),dz=(k.v?1:0)-(k.u?1:0);const mag=Math.hypot(dx,dz);if(mag>1){dx/=mag;dz/=mag}p.st=k.b&&p.y==0?'block':(dx||dz)?'walk':'idle';if(p.st!='block'){const speed=4.8;p.x+=dx*speed*dt;p.z+=dz*speed*dt}
if(k.j&&p.y==0)p.vy=7.5;if(k.d&&p.dodge<=0){p.st='dodge';p.t=0;p.dodge=.65;p.vx=-p.face*8;p.vz=(p.z-o.z)*1.4;snd(520,.12,'sine',.07)}if(p.st!='dodge'&&k.a)begin(p,'punch');else if(p.st!='dodge'&&k.k)begin(p,'kick');else if(p.st!='dodge'&&k.s&&p.mt>=100)begin(p,'sp')}
const a=A[p.st];if(a){if(p.st=='sp'&&p.t<.3&&Math.hypot(o.x-p.x,(o.z||0)-(p.z||0))>1.1){p.x+=p.face*5*dt;p.z+=((o.z||0)-p.z)*2*dt}
if(!p.hit&&p.t>=a.h){p.hit=true;if(Math.hypot(o.x-p.x,(o.z||0)-(p.z||0))<a.r&&o.st!='ko'&&!(o.y>1&&p.st=='punch')){if(o.remote){N.hq++;N.hn=p.st;p.mt=Math.min(100,p.mt+a.dm*1.3)}else hurt(o,p,a,p.st)}}
if(p.t>=a.d)p.st='idle'}
p.y+=p.vy*dt;p.vy-=20*dt;if(p.y<=0){p.y=0;p.vy=0}
p.x+=p.vx*dt;p.vx-=p.vx*Math.min(1,8*dt);p.z+=p.vz*dt;p.vz-=p.vz*Math.min(1,8*dt);
const dx=o.x-p.x,dz=(o.z||0)-p.z,dist=Math.hypot(dx,dz);if(dist<.9&&dist>.001){p.x-=dx/dist*.03;p.z-=dz/dist*.03}
p.x=Math.max(-7.2,Math.min(7.2,p.x));p.z=Math.max(-4.1,Math.min(4.1,p.z))}}
/* pose: ombros, cotovelos, quadris, joelhos, cintura */
function pose(p,T){const f=p.f,s=p.st,t=p.t,a=A[s],k=a?Math.sin(Math.min(t/a.d,1)*Math.PI):0,w=Math.sin(T*10),ar={F:[.5,1.9],B:[.35,2]};
let hF=.35,kF=.25,hB=-.3,kB=.2,ln=0,tw=0,dy=0,gz=0,u=0;const bob=Math.sin(T*5+p.i*2)*.04;
if(s=='walk'){hF=.35+w*.45;hB=-.3-w*.45;kF=.25+Math.max(0,-w)*.5;kB=.2+Math.max(0,w)*.5}
else if(s=='block'){ar.F=[.9,2.3];ar.B=[.9,2.3];ln=.15;dy=-.12;kF=kB=.6;hF=.7;hB=-.5}
else if(s=='punch'){const h=p.sq%2?'B':'F';ar[h]=[.5+1.07*k,1.9-1.9*k];tw=(h=='F'?.5:-.5)*k;ln=.2*k}
else if(s=='kick'){hF=.35+1.65*k;kF=.08;hB=-.2;kB=.4*k;ln=-.25*k;ar.F=[.7,2.1]}
else if(s=='sp'){ar.F=[.5+1.07*k,1.9-1.9*k];ar.B=[.5+1.07*k,1.9-1.9*k];ln=.45*k;kF=.5}
else if(s=='hit'){ln=-.5;ar.F=[-.3,.6];ar.B=[-.3,.6];tw=.3}
else if(s=='victory'){const wave=Math.sin(T*7)*.35;ar.F=[-1.65+wave,-1.9-wave*.5];ar.B=[1.65-wave,1.9+wave*.5];hF=-.45+wave*.25;hB=.45-wave*.25;tw=Math.sin(T*3)*.12;ln=-.18}
 else if(s=='ko'){u=Math.min(t*2.5,1);ar.F=[.2,.3];ar.B=[-.2,.3];hF=.1;hB=-.1;kF=kB=.1}
if(p.y>.2){hF=.9;kF=1.1;hB=.1;kB=1.2}
f.aF.sh.rotation.z=ar.F[0];f.aF.el.rotation.z=ar.F[1];f.aB.sh.rotation.z=ar.B[0];f.aB.el.rotation.z=ar.B[1];
f.lF.hp.rotation.z=hF;f.lF.kn.rotation.z=-kF;f.lB.hp.rotation.z=hB;f.lB.kn.rotation.z=-kB;
f.head.rotation.z=s=='hit'?(p.face>0?-.42:.42):0;f.up.rotation.z=-ln;f.up.rotation.y=tw;f.up.position.y=1.45+bob+dy;f.g.rotation.y=p.face>0?Math.PI/2:-Math.PI/2;f.g.rotation.z=u*1.5;f.g.position.set(p.x,GY+p.y+u*.33,p.z||0)}
/* online + telas */
/* ===== conexão online: WebSocket do server.js (mesma interface que o jogo já usava: peers/presence/leave) ===== */
/*NET-START*/
function joinRoom(code,create){return new Promise((res,rej)=>{
 let ws,mySeat=0;try{ws=new WebSocket((location.protocol==='https:'?'wss://':'ws://')+location.host)}catch(e){return rej(new Error('Abra o jogo pelo endereço do servidor (npm start).'))}
 const peers=new Map();let myId=null,mine={},done=false,closed=false,ka=0,to=0;
 const send=o=>{if(ws.readyState===1)ws.send(JSON.stringify(o))};
 const api={onclose:null,
  peers(){const a=[];if(myId!=null)a.push({peer:myId,presence:mine,sameTab:true,seat:mySeat});peers.forEach(p=>a.push(p));return a},
  presence(patch){const d={};let ch=false;for(const k in patch){if(mine[k]!==patch[k]){d[k]=patch[k];ch=true}}if(ch){mine=Object.assign({},mine,d);send({t:'p',d})}return Promise.resolve()},
  leave(){closed=true;clearInterval(ka);clearTimeout(to);try{ws.close()}catch(e){}return Promise.resolve()}};
 const fail=m=>{if(done)return;done=true;closed=true;clearTimeout(to);clearInterval(ka);try{ws.close()}catch(e){}rej(new Error(m))};
 to=setTimeout(()=>fail('O servidor não respondeu. Tente de novo.'),15000);
 ws.onopen=()=>send({t:'join',code,create:!!create});
 ws.onmessage=e=>{let m;try{m=JSON.parse(e.data)}catch(x){return}
  if(m.t==='joined'){myId=String(m.id);mySeat=Number(m.seat)||0;peers.clear();(m.peers||[]).forEach(p=>peers.set(String(p.id),{peer:String(p.id),presence:p.d||{},sameTab:false,seat:Number(p.seat)||0}));
   if(!done){done=true;clearTimeout(to);ka=setInterval(()=>send({t:'k'}),20000);res(api)}}
  else if(m.t==='in')peers.set(String(m.id),{peer:String(m.id),presence:{},sameTab:false,seat:Number(m.seat)||0});
  else if(m.t==='p'){const id=String(m.id),p=peers.get(id);if(p)peers.set(id,{peer:id,presence:Object.assign({},p.presence,m.d),sameTab:false,seat:p.seat})}
  else if(m.t==='out')peers.delete(String(m.id));
  else if(m.t==='err')fail(m.m||'Erro na sala')};
 ws.onerror=()=>fail('Sem conexão com o servidor.');
 ws.onclose=()=>{clearTimeout(to);clearInterval(ka);if(!done)fail('Sem conexão com o servidor.');else if(!closed){closed=true;if(api.onclose)api.onclose()}};
})}
/*NET-END*/

let RM=null;const N={hq:0,hn:'punch',last:0,jt:0,code:'',go:0,seen:0,host:null,tok:0,played:false,force:false};
const NAME=()=>($('nk').value||'').trim().toUpperCase().slice(0,12);
try{$('nk').value=localStorage.getItem('ab_nm')||''}catch(e){}
$('nk').oninput=()=>{try{localStorage.setItem('ab_nm',NAME())}catch(e){}};
try{G.totalWins=Number(localStorage.getItem('ab_wins')||0)}catch(e){G.totalWins=0}
let profileUid='';try{profileUid=localStorage.getItem('ab_uid')||''}catch(e){}
if(!profileUid){profileUid=(window.crypto&&window.crypto.randomUUID?window.crypto.randomUUID():('ab'+Date.now().toString(36)+Math.random().toString(36).slice(2)));try{localStorage.setItem('ab_uid',profileUid)}catch(e){}}
let friends=[];
function saveProfileStats(){try{localStorage.setItem('ab_wins',String(G.totalWins||0));localStorage.setItem('ab_nm',NAME())}catch(e){};fetch('/api/profile/stats',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({uid:profileUid,wins:G.totalWins||0,coins:G.coins||0})}).catch(()=>{})}
function renderFriends(){const el=$('friend-list');if(!el)return;el.innerHTML='';if(!friends.length){el.textContent='Nenhuma amizade adicionada ainda.';return}friends.forEach(n=>{const row=document.createElement('div');row.className='friend-row';const name=document.createElement('span');name.textContent=n;row.append(name);el.appendChild(row)})}
async function refreshFriends(){try{await fetch('/api/profile',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({uid:profileUid,name:NAME()||'LUTADOR'})});const r=await fetch('/api/friends?uid='+encodeURIComponent(profileUid));const d=await r.json();if(r.ok){friends=(d.friends||[]).map(f=>f.name);renderFriends()}}catch(e){renderFriends()}}
async function addFriend(){const el=$('friend-name'),name=(el.value||'').trim().replace(/[^\p{L}0-9 _-]/gu,'').slice(0,16);if(name.length<2){toast('Digite um nome válido');return}if(name.toLowerCase()===NAME().toLowerCase()){toast('Esse é seu próprio nome');return}try{const r=await fetch('/api/friends/add',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({uid:profileUid,name})});const d=await r.json();if(!r.ok){toast(d.error||'Não foi possível adicionar');return}friends=(d.friends||[]).map(f=>f.name);el.value='';renderFriends();toast(name+' adicionado às amizades!')}catch(e){toast('Conecte-se ao servidor para adicionar amigos')}}
$('friend-add').onclick=addFriend;$('friend-name').addEventListener('keydown',e=>{if(e.key==='Enter')addFriend()});$('nk').addEventListener('change',refreshFriends);refreshFriends();
function toast(t){const e=$('toast');e.textContent=t;e.classList.add('on');clearTimeout(toast.t);toast.t=setTimeout(()=>e.classList.remove('on'),2400)}
function show(id){document.querySelectorAll('.scr').forEach(x=>x.classList.toggle('on',x.id==id));$('menu').style.display=id?'flex':'none'}
let _cls='';function appState(){const pl=['intro','fight','end'].includes(G.st),c=(pl?'p':'')+(G.mode=='local'?'l':'s');if(c==_cls)return;_cls=c;const a=$('app');a.classList.toggle('play',pl);a.classList.toggle('local',G.mode=='local');$('hud').style.display=pl?'flex':'none';$('tb').style.display=pl?'flex':'none'}
function sync(p,q){const r=q.presence,o=P[1-p.i];
if(r.sq!==p.sq||r.st!==p.st){if(r.st=='hit'&&p.st!='hit'){spark(p.x,2,0xffffff);snd(160,.2,'sawtooth',.15);G.shake=.25;G.freeze=.05}
if(r.st=='ko'&&p.st!='ko'&&G.st=='fight'){G.shake=.9;endRound(o)}p.st=r.st;p.t=0;p.sq=r.sq}
p.x+=(r.x-p.x)*Math.min(1,18*dt);p.z+=(Number(r.z||0)-p.z)*Math.min(1,18*dt);p.y=r.y;p.face=r.f;p.hp=r.hp;p.mt=r.mt}
function startMatch(){P.forEach(p=>p.wins=0);G.round=1;show(null);startRound()}
function goLobby(){G.st='lobby';G.slowT=0;msg('');P.forEach(reset);show('s-lobby')}
function lobbyUI(all,ps){$('lc').textContent=N.code;[0,1].forEach(i=>{const q=ps[i];$('sl'+i).classList.toggle('empty',!q);$('ln'+i).textContent=q?String(q.presence.nm||'LUTADOR').slice(0,12):'Aguardando…';$('lt'+i).textContent=q?(q.sameTab?'VOCÊ':i==0?'ANFITRIÃO':'AMIGO'):''});
const host=ps[0]&&ps[0].sameTab,two=ps.length>1,sp=all.length-ps.length;$('bgo').style.display=host?'':'none';$('bgo').disabled=!two;$('bgo').textContent=N.played?'🔁 REVANCHE':'⚔️ COMEÇAR LUTA';
$('lst').textContent=G.me<0?'Sala cheia: você vai assistir a luta.':!two?'Passe o código '+N.code+' para o seu amigo e aguarde ele entrar…':host?'Todos prontos! Toque em COMEÇAR LUTA.':'Aguardando o anfitrião iniciar…'+(sp>0?' ('+sp+' assistindo)':'')}
function netStep(){const all=RM.peers().filter(q=>q.presence&&q.presence.jt!=null).sort((a,b)=>(a.seat??99)-(b.seat??99)),ps=all.slice(0,2);G.me=ps.findIndex(q=>q.sameTab);const s=G.me,h=ps[0];
if(h&&N.host!==h.peer){N.host=h.peer;N.seen=h.presence.go|0}
if(ps.length<2&&G.st!='lobby'&&G.st!='menu')goLobby();
ps.forEach((q,i)=>{const p=P[i],r=q.presence;p.remote=!q.sameTab;if(p.peer!==q.peer){p.peer=q.peer;p.lh=r.hq|0}p.nm=String(r.nm||p.nm).slice(0,12);if(p.remote)sync(p,q)});
P.forEach((p,i)=>{if(!ps[i]){p.remote=false;p.peer=null}});
if(G.st=='lobby'){lobbyUI(all,ps);if(ps.length>1&&h&&!h.sameTab&&(h.presence.go|0)>N.seen){N.seen=h.presence.go|0;N.played=true;startMatch()}}
if(s<0)return;
if(ps.length>1){const p=P[1-s],r=ps[1-s].presence;if((r.hq|0)>p.lh){p.lh=r.hq;if(G.st=='fight'&&A[r.hn])hurt(P[s],p,A[r.hn],r.hn)}}
const now=performance.now();if(now-N.last>33||N.force){N.force=false;N.last=now;const m=P[s];RM.presence({x:+m.x.toFixed(2),y:+m.y.toFixed(2),z:+(m.z||0).toFixed(2),st:m.st,f:m.face,hp:Math.round(m.hp),mt:Math.round(m.mt),sq:m.sq,hq:N.hq,hn:N.hn,go:N.go}).catch(()=>{})}}
function genCode(){const c='ABCDEFGHJKMNPQRSTUVWXYZ23456789';let r='';for(let i=0;i<4;i++)r+=c[Math.random()*c.length|0];return r}
async function enter(code,create){goLand();start('net');N.code=code;const tok=++N.tok;G.st='lobby';show('s-lobby');$('lc').textContent=code;$('lst').textContent='Conectando à sala…';$('bgo').style.display='none';
$('ln0').textContent='Conectando…';$('ln1').textContent='';$('lt0').textContent=$('lt1').textContent='';
let r;try{r=await joinRoom(code,create)}catch(e){if(tok==N.tok){toast((e&&e.message)||'Não consegui entrar na sala');toMenu()}return}
if(tok!=N.tok){r.leave().catch(()=>{});return}
r.onclose=()=>{if(RM===r){toast('Conexão perdida');toMenu()}};
RM=r;N.jt=Date.now()+Math.random();N.hq=0;N.go=0;N.played=false;N.host=null;
RM.presence({jt:N.jt,nm:NAME()||'LUTADOR',hp:100,mt:0,st:'idle',x:0,y:0,z:0,f:1,sq:0,hq:0,hn:'punch',go:0}).catch(()=>{})}
/* moedas e loja de roupas */
function saveCoins(){try{localStorage.setItem('ab_coins',String(G.coins))}catch(e){}$('coin-count').textContent=G.coins;if($('coin-count-shop'))$('coin-count-shop').textContent=G.coins;fetch('/api/profile/stats',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({uid:profileUid,wins:G.totalWins||0,coins:G.coins||0})}).catch(()=>{})}
try{G.coins=Math.max(0,parseInt(localStorage.getItem('ab_coins')||'0',10)||0)}catch(e){}
const outfits=[{name:'Neon Ciano',price:80,color:0x00d9ff},{name:'Ouro Real',price:120,color:0xffc928},{name:'Roxo Cósmico',price:160,color:0x9b55ff},{name:'Verde Toxic',price:200,color:0x53ff72}];
let outfitOwned=[];try{outfitOwned=JSON.parse(localStorage.getItem('ab_outfits')||'[]')}catch(e){}if(outfitOwned.length&&outfits[outfitOwned[0]]){P[0].f.cl.color.setHex(outfits[outfitOwned[0]].color);P[0].f.gl.color.setHex(outfits[outfitOwned[0]].color)}
function wearOutfit(idx){const item=outfits[idx];if(!outfitOwned.includes(idx)){if(G.coins<item.price){toast('Moedas insuficientes!');return}G.coins-=item.price;outfitOwned.push(idx);localStorage.setItem('ab_outfits',JSON.stringify(outfitOwned));saveCoins()}P[0].f.cl.color.setHex(item.color);P[0].f.gl.color.setHex(item.color);toast(item.name+' equipado!');renderShop()}
function renderShop(){const el=$('outfits');el.innerHTML='';outfits.forEach((o,i)=>{const b=document.createElement('button');b.className='btn '+(outfitOwned.includes(i)?'green':'blue');b.textContent=o.name+' · '+(outfitOwned.includes(i)?'EQUIPAR':o.price+' 🪙');b.onclick=()=>wearOutfit(i);el.appendChild(b)});$('coin-count').textContent=G.coins;if($('coin-count-shop'))$('coin-count-shop').textContent=G.coins}
/* menu */
const CN=[['👁','1ª','Você vê pelos seus olhos, com as luvas na frente.'],['🥊','2ª','Você vê pelos olhos do rival, como ele te enxerga!'],['🎥','3ª','Câmera atrás do seu ombro, seguindo a ação.'],['📺','TV','Visão clássica de transmissão.']];
CN.forEach((c,i)=>{const b=document.createElement('button');b.className='chip';b.innerHTML='<b>'+c[0]+'</b><em>'+c[1]+'</em>';b.onclick=()=>{G.cam=i+1;camLab()};$('cams').appendChild(b)});
function camLab(){[...$('cams').children].forEach((b,i)=>b.classList.toggle('sel',i+1==G.cam));$('camd').textContent=CN[G.cam-1][2];$('cb').textContent='📷 '+CN[G.cam-1][0]}
function camNext(){G.cam=G.cam%4+1;camLab()}camLab();$('cb').onclick=camNext;
function leave(){N.tok++;if(RM){RM.leave().catch(()=>{});RM=null}}
function toMenu(){leave();G.st='menu';G.mode='cpu';G.me=0;msg('');show('s-home');P.forEach(p=>{p.remote=false;p.cpu=false;p.peer=null;reset(p)})}
function start(mode){leave();G.mode=mode;G.me=0;G.slowT=0;P.forEach(p=>{p.wins=0;p.remote=false;p.cpu=false;p.peer=null;p.nm=p.i?'AZUL':(NAME()||'VERMELHO')});if(mode=='cpu'){P[1].cpu=true;P[1].nm='CPU'}P.forEach(reset);
if(mode!='net'){show(null);G.round=1;startRound()}}
$('b1').onclick=()=>{goLand();start('cpu')};$('b2').onclick=()=>{goLand();start('local')};
$('b3').onclick=()=>{if(!NAME()){toast('Digite seu nome primeiro');$('nk').focus();return}goLand();$('who').textContent='👤 Lutando como '+NAME();show('s-online')};
$('bb1').onclick=()=>show('s-home');$('shop-open').onclick=()=>{renderShop();show('s-shop')};$('shop-back').onclick=()=>show('s-home');$('bc').onclick=()=>enter(genCode(),true);
$('bj').onclick=()=>{const c=$('cd').value.toUpperCase().replace(/[^A-Z0-9]/g,'');if(c.length<3){toast('Digite o código da sala');return}enter(c)};
$('bl').onclick=toMenu;$('xb').onclick=toMenu;
$('bgo').onclick=()=>{if(!RM||G.st!='lobby'||G.me!=0)return;N.go++;N.force=true;N.played=true;startMatch()};
$('bcp').onclick=()=>{const t='Venha lutar no ARENA BRAWL 3D! Código da sala: '+N.code+' — '+location.origin;
if(navigator.share){navigator.share({text:t}).catch(()=>{});return}
try{navigator.clipboard.writeText(t).then(()=>toast('Convite copiado! Código: '+N.code)).catch(()=>toast('Código da sala: '+N.code))}catch(e){toast('Código da sala: '+N.code)}};
/* camera: 1ª, 2ª (olhos do rival), 3ª (atras do ombro), TV */
const cl=new V3(),tp=new V3(),tl=new V3();
function camUpd(T,raw){const s=G.me>=0?G.me:0,me=P[s],op=P[1-s],m=G.st=='menu'||G.st=='lobby'||G.me<0?4:G.cam,fp=m<3,ow=m==1?me:op,tg=m==1?op:me;
P.forEach(p=>{const h=fp&&p==ow,f=p.f;f.body.visible=!h;f.lF.hp.visible=f.lB.hp.visible=!h;f.aF.sh.position.z=h?.28:.5;f.aB.sh.position.z=h?-.28:-.5});front.visible=m<4;
let fov=45,k=8;
if(fp){const forward=ow.face||1;tp.set(ow.x-forward*.38,GY+ow.y+2.72,ow.z||0);tl.set(ow.x+forward*5,2.15,(ow.z||0)+((tg.z||0)-(ow.z||0))*.25);fov=cam.aspect<1?86:72;k=18}
else if(m==3){const forward=me.face||1;tp.set(me.x-forward*3.5,4.0,(me.z||0)+3.5);tl.set(me.x+(op.x-me.x)*.65,1.8,(me.z||0)+((op.z||0)-(me.z||0))*.5);fov=58;k=7}
else{const mx=(P[0].x+P[1].x)/2,mz=((P[0].z||0)+(P[1].z||0))/2,d=Math.abs(P[0].x-P[1].x),ang=G.st=='menu'||G.st=='lobby'?Math.sin(T*.4)*.6:0;tp.set(mx*.6+Math.sin(ang)*11,5.2,Math.min(12,Math.cos(ang)*(9+d*.25))+mz*.25);tl.set(mx*.6,1.5,mz)}
const a=1-Math.exp(-k*raw);cam.position.lerp(tp,a);cl.lerp(tl,a);cam.fov+=(fov-cam.fov)*.15;cam.updateProjectionMatrix();cam.position.x+=(Math.random()-.5)*G.shake;cam.position.y+=(Math.random()-.5)*G.shake;cam.lookAt(cl);G.shake*=.9}
/* loop */
let last=performance.now(),crowdFrame=0;const tv=new V3();
function loop(now){requestAnimationFrame(loop);const raw=Math.min(.05,(now-last)/1000);last=now;const T=now/1000;dt=raw;
if(G.freeze>0){G.freeze-=raw;dt=0}else if(G.slowT>0){G.slowT-=raw;dt=raw*.3}
if(G.mode=='net'&&RM)netStep();
if(G.st=='intro'){G.introT+=raw;if(G.introT>2.35&&G.introT<3.75)msg('ROUND '+G.round);else if(G.introT>=3.75&&G.introT<4.25)msg('LUTEM!');else if(G.introT>=4.25){msg('');$('intro-card').classList.remove('show');G.st='fight'}}
if(G.st=='fight'){G.time-=dt;if(G.time<=0){const[a,b]=P;endRound(a.hp==b.hp?null:a.hp>b.hp?a:b)}}
if(G.st=='menu'||G.st=='lobby'){P.forEach((p,i)=>{p.x=i?3:-3;p.z=i?1.1:-1.1;p.face=i?-1:1;p.st='idle';p.t+=dt})}else{upd(P[0],P[1]);upd(P[1],P[0])}
P.forEach(p=>pose(p,T));
[0,1].forEach(i=>{const p=P[i];$('h'+(i+1)).style.width=p.hp+'%';$('m'+(i+1)).style.width=p.mt+'%';$('mm'+(i+1)).className='mt'+(p.mt>=100?' f':'');$('n'+(i+1)).textContent=p.nm});$('rd').textContent=['intro','fight','end'].includes(G.st)?'R'+G.round+' · '+Math.ceil(Math.max(0,G.time)):'';
for(let i=sparks.length-1;i>=0;i--){const s=sparks[i];s.l-=raw;s.m.position.addScaledVector(s.v,raw);s.v.y-=(s.g||12)*raw;s.m.rotation.x+=raw*8;s.m.scale.setScalar(Math.min(1,s.l*2));if(s.l<=0){S.remove(s.m);sparks.splice(i,1)}}
crowdUpd(T,G.st=='end'||G.shake>.3);
beams.forEach((b,i)=>{b.pv.rotation.z=Math.sin(T*.8+i*2)*.5;b.pv.rotation.x=Math.cos(T*.6+i)*.4;b.pv.updateMatrixWorld();b.l.target.position.copy(b.pv.localToWorld(tv.set(0,-13,0)))});
appState();document.querySelectorAll('.ab.s').forEach(b=>b.classList.toggle('rdy',P[+b.parentNode.dataset.p].mt>=100));camUpd(T,raw);R.render(S,cam)}
pips();requestAnimationFrame(loop);
