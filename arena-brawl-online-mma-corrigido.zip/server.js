const http=require('http'),fs=require('fs'),path=require('path'),{WebSocketServer}=require('ws');
const FILES={'/':'index.html','/index.html':'index.html','/style.css':'style.css','/game.js':'game.js'};
const TYPE={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8'};
const PROFILE_FILE=path.join(__dirname,'profiles.json');
let profiles={};try{profiles=JSON.parse(fs.readFileSync(PROFILE_FILE,'utf8'))||{}}catch(e){profiles={}}
const saveProfiles=()=>{try{fs.writeFileSync(PROFILE_FILE,JSON.stringify(profiles,null,2))}catch(e){console.error('Não foi possível salvar perfis:',e.message)}};
const sendJson=(r,code,obj)=>{r.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});r.end(JSON.stringify(obj))};
const readBody=q=>new Promise(resolve=>{let b='';q.on('data',c=>{b+=c;if(b.length>4096)q.destroy()});q.on('end',()=>{try{resolve(JSON.parse(b||'{}'))}catch(e){resolve({})}});q.on('error',()=>resolve({}))});
const cleanUid=v=>String(v||'').replace(/[^a-zA-Z0-9_-]/g,'').slice(0,64);
const cleanName=v=>String(v||'').trim().replace(/[^\p{L}0-9 _-]/gu,'').slice(0,16).toUpperCase();
const srv=http.createServer(async(q,r)=>{
 const u=new URL(q.url,'http://localhost');
 if(u.pathname==='/api/profile'&&q.method==='POST'){
  const b=await readBody(q),uid=cleanUid(b.uid),name=cleanName(b.name);if(uid.length<8||name.length<2)return sendJson(r,400,{error:'Nome ou perfil inválido'});
  const old=profiles[uid]||{uid,friends:[],wins:0,coins:0};old.name=name;old.updated=Date.now();profiles[uid]=old;saveProfiles();return sendJson(r,200,{ok:true,profile:old});
 }
 if(u.pathname==='/api/friends'&&q.method==='GET'){
  const uid=cleanUid(u.searchParams.get('uid')),p=profiles[uid];if(!p)return sendJson(r,404,{error:'Perfil não encontrado'});
  return sendJson(r,200,{friends:(p.friends||[]).map(id=>profiles[id]).filter(Boolean).map(f=>({uid:f.uid,name:f.name}))});
 }
 if(u.pathname==='/api/friends/add'&&q.method==='POST'){
  const b=await readBody(q),uid=cleanUid(b.uid),name=cleanName(b.name),p=profiles[uid];if(!p)return sendJson(r,404,{error:'Crie seu perfil primeiro'});
  const matches=Object.values(profiles).filter(f=>f.uid!==uid&&f.name.toLowerCase()===name.toLowerCase());
  if(matches.length===0)return sendJson(r,404,{error:'Esse jogador ainda não criou um perfil no jogo'});
  if(matches.length>1)return sendJson(r,409,{error:'Há mais de um jogador com esse nome. Peça um nome diferente.'});
  const friend=matches[0];p.friends=p.friends||[];friend.friends=friend.friends||[];if(!p.friends.includes(friend.uid))p.friends.push(friend.uid);if(!friend.friends.includes(uid))friend.friends.push(uid);saveProfiles();
  return sendJson(r,200,{ok:true,friends:p.friends.map(id=>profiles[id]).filter(Boolean).map(f=>({uid:f.uid,name:f.name}))});
 }
 if(u.pathname==='/api/profile/stats'&&q.method==='POST'){
  const b=await readBody(q),uid=cleanUid(b.uid),p=profiles[uid];if(!p)return sendJson(r,404,{error:'Perfil não encontrado'});
  p.wins=Math.max(0,Math.min(1e9,Number(b.wins)||0));p.coins=Math.max(0,Math.min(1e9,Number(b.coins)||0));saveProfiles();return sendJson(r,200,{ok:true});
 }
 const f=FILES[u.pathname];if(!f){r.writeHead(404);return r.end('404')}
 r.writeHead(200,{'Content-Type':TYPE[path.extname(f)],'Cache-Control':'no-cache'});fs.createReadStream(path.join(__dirname,f)).pipe(r)
});
const wss=new WebSocketServer({server:srv,maxPayload:2048}),rooms={},MAX=8;let uid=1;
const num=(v,lo,hi)=>{v=+v;return Number.isFinite(v)?Math.max(lo,Math.min(hi,v)):0};
const str=v=>String(v==null?'':v).slice(0,12);
/* só deixa passar os campos que o jogo usa, com tipo e limite certos */
function clean(d){const o={};if(!d||typeof d!=='object')return o;
 if('jt' in d)o.jt=num(d.jt,0,1e15);
 ['nm','st','hn'].forEach(k=>{if(k in d)o[k]=str(d[k])});
 ['x','y','z'].forEach(k=>{if(k in d)o[k]=num(d[k],-1000,1000)});
 ['hp','mt'].forEach(k=>{if(k in d)o[k]=num(d[k],0,1000)});
 ['sq','hq','go'].forEach(k=>{if(k in d)o[k]=Math.floor(num(d[k],0,2e9))});
 if('f' in d)o.f=+d.f<0?-1:1;
 return o}
const bc=(r,o,ex)=>{const s=JSON.stringify(o);r.p.forEach(p=>{if(p!==ex&&p.ws.readyState===1)p.ws.send(s)})};
wss.on('connection',ws=>{let me=null,room=null,cnt=0,ts=Date.now();ws.isAlive=true;ws.on('pong',()=>{ws.isAlive=true});
 const err=t=>{try{ws.send(JSON.stringify({t:'err',m:t}));ws.close()}catch(e){}};
 ws.on('message',raw=>{
  const now=Date.now();if(now-ts>1000){ts=now;cnt=0}if(++cnt>200)return;
  let m;try{m=JSON.parse(raw)}catch{return}
  if(m.t==='join'&&!me){
   const c=String(m.code||'').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,6);
   if(c.length<3)return err('Código inválido');
   let r=rooms[c];
   if(m.create){if(r)return err('Esse código já está em uso. Tente de novo.');r=rooms[c]={code:c,p:new Map()}}
   else if(!r)return err('Sala não encontrada');
   if(r.p.size>=MAX)return err('Sala cheia');
   let seat=0;while([...r.p.values()].some(p=>p.seat===seat))seat++;me={id:uid++,ws,d:{},seat};room=r;
   ws.send(JSON.stringify({t:'joined',id:me.id,seat:me.seat,peers:[...r.p.values()].map(p=>({id:p.id,d:p.d,seat:p.seat}))}));
   bc(r,{t:'in',id:me.id,seat:me.seat},me);r.p.set(me.id,me);
  }else if(!me)return;
  else if(m.t==='p'){const d=clean(m.d);Object.assign(me.d,d);bc(room,{t:'p',id:me.id,d},me)}
 });
 ws.on('close',()=>{if(!me)return;room.p.delete(me.id);if(!room.p.size)delete rooms[room.code];else bc(room,{t:'out',id:me.id})});
});
/* derruba conexões mortas (celular que perdeu o sinal) */
setInterval(()=>wss.clients.forEach(ws=>{if(!ws.isAlive)return ws.terminate();ws.isAlive=false;ws.ping()}),30000);
srv.listen(process.env.PORT||3000,()=>console.log('ARENA BRAWL 3D rodando na porta '+(process.env.PORT||3000)));
